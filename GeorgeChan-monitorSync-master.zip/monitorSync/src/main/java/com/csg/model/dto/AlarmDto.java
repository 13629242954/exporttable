package com.csg.model.dto;

import lombok.Data;
import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 变电告警表 数据传输对象
 * </p>
 *
 * @author George Chan
 * @since 2019-11-21
 */
@Data
public class AlarmDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private String id;

    /**
     * 区域标记
     */
    private Integer unit_sign;

    /**
     * 区域名称
     */
    private String unit_title;

    /**
     * 区域值（0,1）
     */
    private Integer unit_value;

    /**
     * 报警时间
     */
    private Date alarm_time;

    /**
     * 短信状态
     */
    private Integer sms_status;

    /**
     * 站室编码
     */
    private String authorizeid;

    /**
     * 机器人ID
     */
    private String robot_id;
    /**
     * 操作类型
     */
    private String EventType;
}
