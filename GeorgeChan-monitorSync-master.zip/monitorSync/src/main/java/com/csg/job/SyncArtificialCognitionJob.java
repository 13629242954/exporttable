package com.csg.job;

import com.csg.service.IArtificialCognitionService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * <p>
 *
 * </p>
 *
 * @author GeorgeChan 2019/11/25 18:46
 * @version 1.0
 * @since jdk1.8
 */
public class SyncArtificialCognitionJob extends QuartzJobBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(SyncArtificialCognitionJob.class);
    private final IArtificialCognitionService artificialCognitionService;

    @Autowired
    public SyncArtificialCognitionJob(IArtificialCognitionService artificialCognitionService) {
        this.artificialCognitionService = artificialCognitionService;
    }

    @Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        LOGGER.info("开始同步 rt_alarm 告警数据");
        artificialCognitionService.syncData();
        LOGGER.info("结束同步 rt_alarm 告警数据");
    }
}
