package com.csg.job;

import com.csg.service.IThermalDefectService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * <p>
 *  热缺陷记录表 数据同步
 * </p>
 *
 * @author GeorgeChan 2019/11/25 17:22
 * @version 1.0
 * @since jdk1.8
 */
public class SyncThermalDefectJob extends QuartzJobBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(SyncThermalDefectJob.class);
    private final IThermalDefectService thermalDefectService;

    @Autowired
    public SyncThermalDefectJob(IThermalDefectService thermalDefectService) {
        this.thermalDefectService = thermalDefectService;
    }

    @Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        LOGGER.info("开始同步 rt_thermal_defect 数据");
        thermalDefectService.syncData();
        LOGGER.info("结束同步 rt_thermal_defect 数据");
    }
}
