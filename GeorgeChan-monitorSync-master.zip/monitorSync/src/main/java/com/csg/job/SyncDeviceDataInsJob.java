package com.csg.job;

import com.csg.service.IDeviceDataInsService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * <p>
 *  仪表识别表 数据同步
 * </p>
 *
 * @author GeorgeChan 2019/11/25 16:23
 * @version 1.0
 * @since jdk1.8
 */
public class SyncDeviceDataInsJob extends QuartzJobBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(SyncDataDetailJob.class);
    private final IDeviceDataInsService deviceDataInsService;

    @Autowired
    public SyncDeviceDataInsJob(IDeviceDataInsService deviceDataInsService) {
        this.deviceDataInsService = deviceDataInsService;
    }

    @Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        LOGGER.info("开始同步 rt_device_data_ins 数据");
        deviceDataInsService.syncData();
        LOGGER.info("结束同步 rt_device_data_ins 数据");
    }
}
