package com.csg.job;

import com.csg.service.IAlarmService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * <p>
 *  车体告警记录 数据同步
 * </p>
 *
 * @author GeorgeChan 2019/11/25 15:24
 * @version 1.0
 * @since jdk1.8
 */
public class SyncAlarmJob extends QuartzJobBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(SyncAlarmJob.class);
    private final IAlarmService alarmService;

    @Autowired
    public SyncAlarmJob(IAlarmService alarmService) {
        this.alarmService = alarmService;
    }

    @Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        LOGGER.info("开始同步 rt_alarm 告警数据");
        alarmService.syncData();
        LOGGER.info("结束同步 rt_alarm 告警数据");
    }
}
