package com.csg.job;

import com.csg.service.ITaskDetailService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * <p>
 *  任务详细表 数据同步
 * </p>
 *
 * @author GeorgeChan 2019/11/25 17:11
 * @version 1.0
 * @since jdk1.8
 */
public class SyncTaskDetailJob extends QuartzJobBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(SyncTaskDetailJob.class);
    private final ITaskDetailService taskDetailService;

    @Autowired
    public SyncTaskDetailJob(ITaskDetailService taskDetailService) {
        this.taskDetailService = taskDetailService;
    }

    @Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        LOGGER.info("开始同步 rt_task_detail 数据");
        taskDetailService.syncData();
        LOGGER.info("结束同步 rt_task_detail 数据");
    }
}
