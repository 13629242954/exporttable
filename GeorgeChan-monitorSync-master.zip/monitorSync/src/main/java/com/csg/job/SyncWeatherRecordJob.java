package com.csg.job;

import com.csg.service.IWeatherRecordService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * <p>
 *  历史气象信息 数据同步
 * </p>
 *
 * @author GeorgeChan 2019/11/25 17:27
 * @version 1.0
 * @since jdk1.8
 */
public class SyncWeatherRecordJob extends QuartzJobBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(SyncWeatherRecordJob.class);
    private final IWeatherRecordService weatherRecordService;

    @Autowired
    public SyncWeatherRecordJob(IWeatherRecordService weatherRecordService) {
        this.weatherRecordService = weatherRecordService;
    }

    @Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        LOGGER.info("开始同步 rt_weather_record 数据");
        weatherRecordService.syncData();
        LOGGER.info("结束同步 rt_weather_record 数据");
    }
}
