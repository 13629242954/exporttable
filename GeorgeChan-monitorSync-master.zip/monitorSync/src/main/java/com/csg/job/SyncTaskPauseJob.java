package com.csg.job;

import com.csg.service.ITaskPauseService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * <p>
 *
 * </p>
 *
 * @author GeorgeChan 2019/11/25 17:14
 * @version 1.0
 * @since jdk1.8
 */
public class SyncTaskPauseJob extends QuartzJobBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(SyncTaskPauseJob.class);
    private final ITaskPauseService taskPauseService;

    @Autowired
    public SyncTaskPauseJob(ITaskPauseService taskPauseService) {
        this.taskPauseService = taskPauseService;
    }

    @Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        LOGGER.info("开始同步 rt_task_pause 数据");
        taskPauseService.syncData();
        LOGGER.info("结束同步 rt_task_pause 数据");
    }
}
