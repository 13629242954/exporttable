package com.csg.job;

import com.csg.service.ISpecialTaskService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * <p>
 *  特例巡检任务表 数据同步
 * </p>
 *
 * @author GeorgeChan 2019/11/25 17:03
 * @version 1.0
 * @since jdk1.8
 */
public class SyncSpecialTaskJob extends QuartzJobBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(SyncSpecialTaskJob.class);
    private final ISpecialTaskService specialTaskService;

    @Autowired
    public SyncSpecialTaskJob(ISpecialTaskService specialTaskService) {
        this.specialTaskService = specialTaskService;
    }

    @Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        LOGGER.info("开始同步 rt_special_task 数据");
        specialTaskService.syncData();
        LOGGER.info("结束同步 rt_special_task 数据");
    }
}
