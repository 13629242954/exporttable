package com.csg.job;

import com.csg.service.IDeviceDataInfService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * <p>
 *  红外数据表 数据同步
 * </p>
 *
 * @author GeorgeChan 2019/11/25 16:19
 * @version 1.0
 * @since jdk1.8
 */
public class SyncDeviceDataInfJob extends QuartzJobBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(SyncDataDetailJob.class);
    private final IDeviceDataInfService deviceDataInfService;

    @Autowired
    public SyncDeviceDataInfJob(IDeviceDataInfService deviceDataInfService) {
        this.deviceDataInfService = deviceDataInfService;
    }

    @Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        LOGGER.info("开始同步 rt_device_data_inf 数据");
        deviceDataInfService.syncData();
        LOGGER.info("结束同步 rt_device_data_inf 数据");
    }
}
