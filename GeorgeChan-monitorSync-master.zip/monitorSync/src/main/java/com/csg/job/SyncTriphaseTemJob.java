package com.csg.job;

import com.csg.service.ITriphaseTemService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * <p>
 *  三项温差对比记录表 数据同步
 * </p>
 *
 * @author GeorgeChan 2019/11/25 17:24
 * @version 1.0
 * @since jdk1.8
 */
public class SyncTriphaseTemJob extends QuartzJobBean {
    private static final Logger LOGGER = LoggerFactory.getLogger(SyncTriphaseTemJob.class);
    private final ITriphaseTemService triphaseTemService;

    @Autowired
    public SyncTriphaseTemJob(ITriphaseTemService triphaseTemService) {
        this.triphaseTemService = triphaseTemService;
    }

    @Override
    protected void executeInternal(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        LOGGER.info("开始同步 rt_triphase_tem 数据");
        triphaseTemService.syncData();
        LOGGER.info("结束同步 rt_triphase_tem 数据");
    }
}
