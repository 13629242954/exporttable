package com.csg.enums;

/**
 * <p>
 *  数据同步的 操作类型
 * </p>
 *
 * @author GeorgeChan 2019/11/21 19:21
 * @version 1.0
 * @since jdk1.8
 */
public enum EventTypeEnums {
    INSERT("INSERT", "新增"),
    UPDATE("UPDATE", "更新"),
    DELETE("DELETE", "删除")
    ;
    private final String key;
    private final String desc;

    EventTypeEnums(String key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public String getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }
}
