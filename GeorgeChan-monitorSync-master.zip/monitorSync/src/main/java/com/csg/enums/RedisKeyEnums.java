package com.csg.enums;

/**
 * <p>
 *  redis 数据同步key的枚举类
 * </p>
 *
 * @author GeorgeChan 2019/11/21 15:52
 * @version 1.0
 * @since jdk1.8
 */
public enum RedisKeyEnums {
    RT_ALARM("rt_alarm", "车体告警记录"),
    RT_DEVICE_DATA_INF("rt_device_data_inf","红外数据表"),
    RT_DEVICE_DATA_INS("rt_device_data_ins","仪表识别表"),
    RT_ENERGY_LOG("rt_energy_log","电池电量记录表"),
    RT_OIL_RECORD("rt_oil_record","油温油位记录表"),
    RT_WEATHER_RECORD("rt_weather_record","历史气象信息"),
    RT_DATA_DETAIL("rt_data_detail","任务数据详细表"),
    RT_TASK_DATA("rt_task_data","任务详细表"),
    RT_THERMAL_DEFECT("rt_thermal_defect","热缺陷记录表"),
    RT_TRIPHASE_TEM("rt_triphase_tem","三项温差对比记录表"),
    RT_TASK_PLANE("rt_task_plane","任务计划表"),
    RT_TASK_PAUSE("rt_task_pause","任务暂停表"),
    RT_TASK_DETAIL("rt_task_detail","任务详细表"),
    RT_SPECIAL_TASK("rt_special_task","特例巡检任务表"),
    RT_SMS("rt_sms","短信记录表"),
    RT_OIL_LIMIT("rt_oil_limit","油温油位界限表"),
    RT_MEDIA_MANAGE("rt_media_manage","多媒体管理表"),
    RT_DEVICE_ALARM("rt_device_alarm","设备告警表"),
    RT_ARTIFICIAL_COGNITION("rt_artificial_cognition","rt_artificial_cognition"),
    RT_ENVIRONMENT_INFO("rt_environment_info","rt_environment_info")
    ;

    private final String key;
    private final String desc;

    RedisKeyEnums(String key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public String getKey() {
        return key;
    }

    public String getDesc() {
        return desc;
    }
}
