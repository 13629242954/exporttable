package com.csg.mapper;

import com.csg.entity.Alarm;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 变电告警表 Mapper 接口
 * </p>
 *
 * @author George Chan
 * @since 2019-11-21
 */
public interface AlarmMapper extends BaseMapper<Alarm> {

}
