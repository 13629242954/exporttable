package com.csg.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.csg.entity.QuartzJob;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author George
 * @since 2019-11-15
 */
public interface QuartzJobMapper extends BaseMapper<QuartzJob> {
    List<QuartzJob> listJob(@Param("jobName") String jobName);

    QuartzJob getJob(@Param("jobName") String jobName, @Param("jobGroup") String jobGroup);

    int saveJob(QuartzJob job);

    int updateJobStatus(@Param("jobName") String jobName, @Param("jobGroup") String jobGroup, @Param("status") String status);

    int removeQuartzJob(@Param("jobName") String jobName, @Param("jobGroup") String jobGroup);

    int updateJob(QuartzJob quartz);
}
