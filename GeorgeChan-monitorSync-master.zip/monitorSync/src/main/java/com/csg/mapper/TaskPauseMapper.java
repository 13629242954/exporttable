package com.csg.mapper;

import com.csg.entity.TaskPause;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 暂停任务 Mapper 接口
 * </p>
 *
 * @author George Chan
 * @since 2019-11-24
 */
public interface TaskPauseMapper extends BaseMapper<TaskPause> {

}
