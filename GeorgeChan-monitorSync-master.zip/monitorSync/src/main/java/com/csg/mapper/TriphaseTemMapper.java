package com.csg.mapper;

import com.csg.entity.TriphaseTem;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 三相温差对比记录 Mapper 接口
 * </p>
 *
 * @author George Chan
 * @since 2019-11-24
 */
public interface TriphaseTemMapper extends BaseMapper<TriphaseTem> {

}
