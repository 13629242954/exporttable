package com.csg.mapper;

import com.csg.entity.TaskData;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author George Chan
 * @since 2019-11-24
 */
public interface TaskDataMapper extends BaseMapper<TaskData> {

}
