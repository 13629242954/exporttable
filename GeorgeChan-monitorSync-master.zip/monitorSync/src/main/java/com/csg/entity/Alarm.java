package com.csg.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 变电告警表
 * </p>
 *
 * @author George Chan
 * @since 2019-11-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("RT_ALARM")
public class Alarm implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId(value = "ID", type = IdType.ID_WORKER)
    private String id;

    /**
     * 区域标记
     */
    @TableField("UNIT_SIGN")
    private Integer unitSign;

    /**
     * 区域名称
     */
    @TableField("UNIT_TITLE")
    private String unitTitle;

    /**
     * 区域值（0,1）
     */
    @TableField("UNIT_VALUE")
    private Integer unitValue;

    /**
     * 报警时间
     */
    @TableField("ALARM_TIME")
    private Date alarmTime;

    /**
     * 短信状态
     */
    @TableField("SMS_STATUS")
    private Integer smsStatus;

    /**
     * 站室编码
     */
    @TableField("AUTHORIZEID")
    private String authorizeid;

    /**
     * 机器人ID
     */
    @TableField("ROBOT_ID")
    private String robotId;


}
