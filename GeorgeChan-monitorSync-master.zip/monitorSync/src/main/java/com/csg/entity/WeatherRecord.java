package com.csg.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 历史气象信息
 * </p>
 *
 * @author George Chan
 * @since 2019-11-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("RT_WEATHER_RECORD")
public class WeatherRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 气象标记
     */
    @TableField("WR_ID")
    private Integer wrId;

    /**
     * 温度 （摄氏度）
     */
    @TableField("WR_TEM")
    private BigDecimal wrTem;

    /**
     * 湿度 （%RH）
     */
    @TableField("WR_HUMIDITY")
    private BigDecimal wrHumidity;

    /**
     * 风向（90为正东，180为正南，270为正西，360为正北）
     */
    @TableField("WR_WIND_DIR")
    private Integer wrWindDir;

    /**
     * 风速（m/s）
     */
    @TableField("WR_WIND_SPEED")
    private BigDecimal wrWindSpeed;

    /**
     * 雨量（mm）
     */
    @TableField("WR_RAINFALL")
    private BigDecimal wrRainfall;

    /**
     * 气压（hPa）
     */
    @TableField("WR_AIR_PRE")
    private BigDecimal wrAirPre;

    /**
     * 记录时间
     */
    @TableField("WR_DATE")
    private Date wrDate;

    /**
     * 备注
     */
    @TableField("MARK")
    private String mark;

    /**
     * 站室标识符
     */
    @TableField("AUTHORIZEID")
    private String authorizeid;

    /**
     * 主键
     */
    @TableId(value = "ID", type = IdType.ID_WORKER)
    private String id;

    /**
     * 机器人ID
     */
    @TableField("ROBOT_ID")
    private String robotId;


}
