package com.csg.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author George Chan
 * @since 2019-11-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("RT_DEVICE_DATA_INS")
public class DeviceDataIns implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 设备标记
     */
    @TableField("DEVICE_TAG")
    private Integer deviceTag;

    /**
     * 2016-06-30 18:25:14
     */
    @TableField("DATA_DATE")
    private Date dataDate;

    /**
     * 当前数据所属任务Id，没有时赋值0
     */
    @TableField("TASK_ID")
    private Integer taskId;

    /**
     * 仪表识别图片（地址）
     */
    @TableField("DATA_IMG_URL")
    private String dataImgUrl;

    /**
     * 仪表识别图片（名称）
     */
    @TableField("DATA_IMG_NAME")
    private String dataImgName;

    /**
     * 初始状态
     */
    @TableField("DATA_IDENTITY_STATUS")
    private Integer dataIdentityStatus;

    /**
     * 识别值
     */
    @TableField("DATA_VALUE")
    private String dataValue;

    /**
     * 单位
     */
    @TableField("DATA_UNIT")
    private String dataUnit;

    /**
     * 正常范围
     */
    @TableField("DATA_NORMAL_RANGE")
    private String dataNormalRange;

    /**
     * 识别状态
     */
    @TableField("DATA_STATUS")
    private Integer dataStatus;

    /**
     * 站室标识
     */
    @TableField("AUTHORIZEID")
    private String authorizeid;

    /**
     * id
     */
    @TableId(value = "ID", type = IdType.ID_WORKER)
    private String id;

    /**
     * 机器人ID
     */
    @TableField("ROBOT_ID")
    private String robotId;


}
