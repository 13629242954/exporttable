package com.csg.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 巡检任务
 * </p>
 *
 * @author George Chan
 * @since 2019-11-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("RT_TASK_PLANE")
public class TaskPlane implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 自增主键,-10:缺陷追踪；-2:充电；-1:返航；0特巡；大于0:例巡
     */
    @TableField("TASK_ID")
    private Integer taskId;

    /**
     * 任务名称
     */
    @TableField("TASK_NAME")
    private String taskName;

    /**
     * 任务状态
     */
    @TableField("TASK_STATUS")
    private Integer taskStatus;

    /**
     * 排序状态（0未排序，1排序完）,当rt_task_detail中的顺序排好后，该值变为1
     */
    @TableField("TASK_READY")
    private Integer taskReady;

    /**
     * 任务执行时间，对应界面“执行时间”选项，【立即执行】赋值当前时间，【定时执行】赋值填写的时间
     */
    @TableField("TASK_TIME")
    private Date taskTime;

    /**
     * 重复类型，0:单次; 1:每日重复;
     */
    @TableField("REPEAT_TYPE")
    private Integer repeatType;

    /**
     * 重复附加标记, Repeat_type为0或1时为空；
     */
    @TableField("REPEAT_TAG")
    private String repeatTag;

    /**
     * 该任务包含的设备总数
     */
    @TableField("DEVICE_TOTAL")
    private Integer deviceTotal;

    /**
     * 任务预计时间，单位为小时，如0.60小时
     */
    @TableField("EXPECT_TIME")
    private BigDecimal expectTime;

    /**
     * 执行完任务是否执行缺陷设备巡检0：不执行 1：执行
     */
    @TableField("IS_RECHECK")
    private Integer isRecheck;

    /**
     * 任务描述
     */
    @TableField("TASK_MARK")
    private String taskMark;

    /**
     * 最后一次编辑时间
     */
    @TableField("EDIT_TIME")
    private Date editTime;

    /**
     * 任务大类型
     */
    @TableField("TASK_TYPE")
    private Integer taskType;

    /**
     * 任务小类型
     */
    @TableField("SUB_TYPE")
    private String subType;

    /**
     * 站室标识符
     */
    @TableField("AUTHORIZEID")
    private String authorizeid;

    /**
     * ID主键
     */
    @TableId(value = "ID", type = IdType.ID_WORKER)
    private String id;

    /**
     * 机器人ID
     */
    @TableField("ROBOT_ID")
    private String robotId;


}
