package com.csg.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 设备告警
 * </p>
 *
 * @author George Chan
 * @since 2019-11-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("RT_DEVICE_ALARM")
public class DeviceAlarm implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键，自增ID
     */
    @TableField("ALARM_ID")
    private Integer alarmId;

    /**
     * 设备标示ID
     */
    @TableField("DEVICE_TAG")
    private Integer deviceTag;

    /**
     * 告警日期时间
     */
    @TableField("ALARM_DATE")
    private Date alarmDate;

    /**
     * 告警值，巡检结果值
     */
    @TableField("ALARM_VALUE")
    private BigDecimal alarmValue;

    /**
     * 界限值
     */
    @TableField("DATA_UNIT")
    private String dataUnit;

    /**
     * 单位
     */
    @TableField("LIMIT_VALUE")
    private String limitValue;

    /**
     * 告警级别（3-三相温差报警；4-识别内容异常报警5-设备识别异常报警；6-预警报警；7-一般报警；8-严重报警；9-危急报警；）
     */
    @TableField("ALARM_LEVEL")
    private Integer alarmLevel;

    /**
     * 告警状态（0-不告警；1-告警），告警确认后变为0
     */
    @TableField("ALARM_STATUS")
    private Integer alarmStatus;

    /**
     * 取消报警时间
     */
    @TableField("CANCLE_DATE")
    private Date cancleDate;

    /**
     * 描述
     */
    @TableField("ALARM_MARK")
    private String alarmMark;

    /**
     * 为华云app服务，判断告警状态是否已上送，避免重复上送0未上送，1已上送
     */
    @TableField("SMS_STATUS")
    private Integer smsStatus;

    /**
     * 站室标识符
     */
    @TableField("AUTHORIZEID")
    private String authorizeid;

    /**
     * 主键
     */
    @TableId(value = "ID", type = IdType.ID_WORKER)
    private String id;

    /**
     * 机器人id
     */
    @TableField("ROBOT_ID")
    private String robotId;


}
