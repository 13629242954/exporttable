package com.csg.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author George Chan
 * @since 2019-11-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("RT_MEDIA_MANAGE")
public class MediaManage implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId(value = "ID", type = IdType.ID_WORKER)
    private String id;

    @TableField("FILE_NAME")
    private String fileName;

    @TableField("FILE_PATH")
    private String filePath;

    @TableField("FILE_TYPE")
    private Integer fileType;

    @TableField("FILE_SIZE")
    private Integer fileSize;

    @TableField("IP")
    private String ip;

    @TableField("CREATE_TIME")
    private Date createTime;

    /**
     * 站室标识符
     */
    @TableField("AUTHORIZEID")
    private String authorizeid;

    /**
     * 机器人ID
     */
    @TableField("ROBOT_ID")
    private String robotId;


}
