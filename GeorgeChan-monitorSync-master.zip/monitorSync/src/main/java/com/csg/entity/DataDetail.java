package com.csg.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author George Chan
 * @since 2019-11-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("RT_DATA_DETAIL")
public class DataDetail implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 任务Id
     */
    @TableField("TASK_ID")
    private Integer taskId;

    /**
     * 任务日期
     */
    @TableField("TASK_DATE")
    private Date taskDate;

    /**
     * 设备ID
     */
    @TableField("DEVICE_TAG")
    private Integer deviceTag;

    /**
     * 数据时间
     */
    @TableField("DATA_DATE")
    private Date dataDate;

    /**
     * 数据值（超量程、外观异常或者真实int型值）
     */
    @TableField("DATA_VALUE")
    private String dataValue;

    /**
     * 单位
     */
    @TableField("DATA_UNIT")
    private String dataUnit;

    /**
     * 识别状态（1正常，0识别异常，2连接异常，3数据超限,4异常（超量程、外观异常））
     */
    @TableField("DATA_STATUS")
    private Integer dataStatus;

    /**
     * 站室标识
     */
    @TableField("AUTHORIZEID")
    private String authorizeid;

    /**
     * 主键id
     */
    @TableId(value = "ID", type = IdType.ID_WORKER)
    private String id;

    /**
     * 机器人id
     */
    @TableField("ROBOT_ID")
    private String robotId;


}
