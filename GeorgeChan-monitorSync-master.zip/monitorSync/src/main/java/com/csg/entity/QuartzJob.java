package com.csg.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author George
 * @since 2019-11-15
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("TB_QUARTZ_JOB")
public class QuartzJob implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableField("ID")
    private Integer id;

    @TableField("JOB_NAME")
    private String jobName;

    @TableField("JOB_GROUP")
    private String jobGroup;

    @TableField("JOB_CLASS_NAME")
    private String jobClassName;

    @TableField("CRON_EXPRESSION")
    private String cronExpression;

    @TableField("TRIGGER_STATE")
    private String triggerState;

    @TableField("OLD_JOB_NAME")
    private String oldJobName;

    @TableField("OLD_JOB_GROUP")
    private String oldJobGroup;

    @TableField("DESCRIPTION")
    private String description;


}
