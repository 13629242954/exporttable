package com.csg.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author George Chan
 * @since 2019-11-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("RT_ENVIRONMENT_INFO")
public class EnvironmentInfo implements Serializable {

    private static final long serialVersionUID = 1L;
    @TableField("ID")
    private String id;

    @TableField("ENV_ID")
    private Integer envId;

    @TableField("ENV_NAME")
    private String envName;

    @TableField("ENV_VALUE")
    private BigDecimal envValue;

    @TableField("ENV_THRESHOLD")
    private BigDecimal envThreshold;

    @TableField("AUTHORIZEID")
    private String authorizeid;

    @TableField("ROBOT_ID")
    private String robotId;


}
