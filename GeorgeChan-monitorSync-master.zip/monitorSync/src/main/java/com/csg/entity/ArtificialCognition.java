package com.csg.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author George Chan
 * @since 2019-11-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("RT_ARTIFICIAL_COGNITION")
public class ArtificialCognition implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableField("ID")
    private String id;

    @TableField("DATA_DATE")
    private Date dataDate;

    @TableField("DATA_IMG_URL")
    private String dataImgUrl;

    @TableField("DATA_IMG_NAME")
    private String dataImgName;

    @TableField("RESULT_VALUE")
    private String resultValue;

    @TableField("RESULT_STATUS")
    private Integer resultStatus;

    @TableField("AUTHORIZEID")
    private String authorizeid;

    @TableField("ROBOT_ID")
    private String robotId;


}
