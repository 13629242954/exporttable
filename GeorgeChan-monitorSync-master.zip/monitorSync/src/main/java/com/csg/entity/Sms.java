package com.csg.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 短信发送记录
 * </p>
 *
 * @author George Chan
 * @since 2019-11-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("RT_SMS")
public class Sms implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "ID", type = IdType.ID_WORKER)
    private String id;

    @TableField("CREATE_TIME")
    private String createTime;

    @TableField("UPDATE_TIME")
    private String updateTime;

    @TableField("PHONE")
    private String phone;

    @TableField("SMSCONTENT")
    private String smscontent;

    @TableField("STATE")
    private String state;

    @TableField("DEVICE_TAG")
    private Integer deviceTag;

    @TableField("REQUEST_ID")
    private String requestId;

    /**
     * 发送短信次数
     */
    @TableField("TIMES")
    private Integer times;

    @TableField("ALARM_TYPE")
    private Integer alarmType;

    @TableField("DEVICE_NAME")
    private String deviceName;

    /**
     * 站室标识符
     */
    @TableField("AUTHORIZEID")
    private String authorizeid;

    /**
     * 机器人ID
     */
    @TableField("ROBOT_ID")
    private String robotId;


}
