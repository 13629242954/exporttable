package com.csg.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 三相温差对比记录
 * </p>
 *
 * @author George Chan
 * @since 2019-11-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("RT_TRIPHASE_TEM")
public class TriphaseTem implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    @TableId(value = "ID", type = IdType.ID_WORKER)
    private String id;

    /**
     * 任务ID
     */
    @TableField("TASK_ID")
    private Integer taskId;

    /**
     * 执行时间（记录时间）
     */
    @TableField("TASK_DATE")
    private Date taskDate;

    /**
     * 对比设备Tag
     */
    @TableField("DEVICE_TAG_S")
    private Integer deviceTagS;

    /**
     * 对比设备名称
     */
    @TableField("TAG_S_NAME")
    private String tagSName;

    /**
     * 对比设备值
     */
    @TableField("TAG_S_VALUE")
    private BigDecimal tagSValue;

    /**
     * 对比设备url地址
     */
    @TableField("TAG_S_URL")
    private String tagSUrl;

    /**
     * 被对比设备Tag（如：B相）
     */
    @TableField("DEVICE_TAG_E")
    private Integer deviceTagE;

    /**
     * 被对比设备名称
     */
    @TableField("TAG_E_NAME")
    private String tagEName;

    /**
     * 被对比设备值
     */
    @TableField("TAG_E_VALUE")
    private BigDecimal tagEValue;

    /**
     * 被对比设备url
     */
    @TableField("TAG_E_URL")
    private String tagEUrl;

    /**
     * 对比差值（可为正负）
     */
    @TableField("DIFFER_VALUE")
    private BigDecimal differValue;

    /**
     * 对比状态（0：正常，1告警，2对比设备异常，3被对比设备异常，4两个都异常）5.对比设备缺项
     */
    @TableField("DIFFER_STATUS")
    private Integer differStatus;

    /**
     * 取消告警时间
     */
    @TableField("CANCEL_TIME")
    private Date cancelTime;

    /**
     * 描述
     */
    @TableField("MARK")
    private String mark;

    /**
     * 站室标识符
     */
    @TableField("AUTHORIZEID")
    private String authorizeid;

    /**
     * 机器人ID
     */
    @TableField("ROBOT_ID")
    private String robotId;


}
