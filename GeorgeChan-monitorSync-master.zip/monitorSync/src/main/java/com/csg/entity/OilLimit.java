package com.csg.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author George Chan
 * @since 2019-11-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("RT_OIL_LIMIT")
public class OilLimit implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 油位
     */
    @TableField("OIL_LEVEL_TAG")
    private Integer oilLevelTag;

    /**
     * 油温
     */
    @TableField("OIL_TEMPERATURE_TAGS")
    private String oilTemperatureTags;

    /**
     * 系数
     */
    @TableField("COEFFICIENT")
    private BigDecimal coefficient;

    /**
     * 误差
     */
    @TableField("ERROR")
    private Integer error;

    /**
     * 创建时间
     */
    @TableField("CREATE_TIME")
    private Date createTime;

    @TableField("AUTHORIZEID")
    private String authorizeid;

    @TableId(value = "ID", type = IdType.ID_WORKER)
    private String id;

    @TableField("ROBOT_ID")
    private String robotId;


}
