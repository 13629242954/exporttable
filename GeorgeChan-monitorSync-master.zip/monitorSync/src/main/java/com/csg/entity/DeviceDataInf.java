package com.csg.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author George Chan
 * @since 2019-11-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("RT_DEVICE_DATA_INF")
public class DeviceDataInf implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 设备标记即设备ID
     */
    @TableField("DEVICE_TAG")
    private Integer deviceTag;

    /**
     * 2016-06-30 18:25:14
     */
    @TableField("DATA_DATE")
    private Date dataDate;

    /**
     * 任务Id，没有时赋值0
     */
    @TableField("TASK_ID")
    private Integer taskId;

    /**
     * 红外图片（地址）
     */
    @TableField("DATA_IMG_URL")
    private String dataImgUrl;

    /**
     * 红外图片（名称）
     */
    @TableField("DATA_IMG_NAME")
    private String dataImgName;

    /**
     * 设备温度（区域最高温）
     */
    @TableField("DEVICE_TEM")
    private BigDecimal deviceTem;

    /**
     * 区域最低温
     */
    @TableField("R_MIN_TEMP")
    private BigDecimal rMinTemp;

    /**
     * 区域平均温度
     */
    @TableField("R_AVG_TEMP")
    private BigDecimal rAvgTemp;

    /**
     * 过滤温度
     */
    @TableField("FILTER_TEM")
    private BigDecimal filterTem;

    /**
     * 全图最高温
     */
    @TableField("IMG_MAX_TEM")
    private BigDecimal imgMaxTem;

    /**
     * 设备温升
     */
    @TableField("DEVICE_TEM_UP")
    private BigDecimal deviceTemUp;

    /**
     * 环境温度
     */
    @TableField("ENV_TEM")
    private BigDecimal envTem;

    /**
     * 识别状态（1正常，0异常，2连接异常）
     */
    @TableField("DATA_STATUS")
    private Integer dataStatus;

    /**
     * 类型
     */
    @TableField("BURN_TYPE")
    private Integer burnType;

    /**
     * 站室标识符
     */
    @TableField("AUTHORIZEID")
    private String authorizeid;

    /**
     * ID
     */
    @TableId(value = "ID", type = IdType.ID_WORKER)
    private String id;

    /**
     * 机器人Id
     */
    @TableField("ROBOT")
    private String robot;


}
