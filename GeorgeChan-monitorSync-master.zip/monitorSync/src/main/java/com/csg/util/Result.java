package com.csg.util;

import lombok.Data;

/**
 * <p>
 *  返回结果
 * </p>
 *
 * @author GeorgeChan 2019/9/28 10:50
 * @version 1.0
 * @since jdk1.8
 */
@Data
public class Result {
    private boolean flag;
    private Integer code;
    private String message;
    /**
     * 数据集合
     */
    private Object data;
    /**
     * 总数量
     */
    private Long count;

    public Result() {
    }

    public Result(boolean flag, Integer code, String message) {
        this.flag = flag;
        this.code = code;
        this.message = message;
    }

    public Result(boolean flag, Integer code, String message, Object data) {
        this.flag = flag;
        this.code = code;
        this.message = message;
        this.data = data;
    }

    public Result(boolean flag, Integer code, String message, Object data, Long count) {
        this.flag = flag;
        this.code = code;
        this.message = message;
        this.data = data;
        this.count = count;
    }
}
