package com.csg.util;

import java.util.List;

public class PageUtil<T> {

    // 分页结果
    private List<T> records;
    // 总条数
    private Long total;
    // 每页显示的总条数
    private int size = 10;
    // 当前页
    private int current = 1;
    // 总页数
    private Long pages;

    public PageUtil() {
        super();
    }

    public int getCurrent() {
        return current;
    }

    public void setCurrent(int current) {
        this.current = current;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

    public Long getPages() {
        if (this.getSize() == 0L) {
            return 0L;
        } else {
            long pages = this.getTotal() / this.getSize();
            if (this.getTotal() % this.getSize() != 0L) {
                ++pages;
            }
            return pages;
        }
    }

    public void setPages(Long pages) {
        this.pages = pages;
    }

    public List<T> getRecords() {
        return records;
    }

    public void setRecords(List<T> records) {
        this.records = records;
    }

    public PageUtil(int current, int size, Long total) {
        super();
        this.current = current;
        this.size = size;
        this.total = total;
        this.pages = getPages();
    }
}
