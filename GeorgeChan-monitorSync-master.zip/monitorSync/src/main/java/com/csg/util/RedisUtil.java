package com.csg.util;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.DependsOn;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 * Redis工具类
 * </p>
 *
 * @author GeorgeChan 2019/11/12 10:08
 * @version 1.0
 * @since jdk1.8
 */
@Component
@DependsOn("redisTemplate")
public class RedisUtil {
//    @Resource(name="redisTemplate")
    @Autowired
    private RedisTemplate redisTemplate;
    //控制层调用
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Value("${redis.data.size:5000}")
    private long size;

    public long getSyncSize() {
        return size;
    }
    // =============================common============================
    /**
     * 指定缓存的过期时间
     *
     * @param key  key
     * @param time 时间（秒）
     * @return 操作是否成功
     */
    public boolean expire(String key, long time) {
        try {
            if (time > 0) {
                redisTemplate.expire(key, time, TimeUnit.SECONDS);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 根据key获取过期时间
     *
     * @param key key
     * @return 时间（秒）
     */
    public long getExpire(String key) {
        return redisTemplate.getExpire(key);
    }

    /**
     * 判断key是否存在
     *
     * @param key key
     * @return true 存在 false不存在
     */
    public boolean hasKey(String key) {
        try {
            return redisTemplate.hasKey(key);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 删除缓存
     *
     * @param key 可以传值一个或多个
     * @return 是否删除成功
     */
    public boolean del(String... key) {
        if (key != null && key.length > 0) {
            if (key.length == 1) {
                return redisTemplate.delete(key[0]);
            } else {
                return redisTemplate.delete(CollectionUtils.arrayToList(key)) > 0;
            }
        }
        return false;
    }

    // ============================String=============================

    /**
     * 普通缓存的获取
     *
     * @param key 键
     * @return 值
     */
    public Object get(String key) {
        return key == null ? null : redisTemplate.opsForValue().get(key);
    }

    /**
     * 普通缓存放入
     *
     * @param key   键
     * @param value 值
     * @return true成功 false失败
     */
    public boolean set(String key, Object value) {
        try {
            redisTemplate.opsForValue().set(key, value);

            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 普通缓存放入并设置时间
     *
     * @param key   键
     * @param value 值
     * @param time  时间(秒) time要大于0 如果time小于等于0 将设置无限期
     * @return true成功 false 失败
     */
    public boolean set(String key, Object value, long time) {
        try {
            if (time > 0) {
                redisTemplate.opsForValue().set(key, value, time, TimeUnit.SECONDS);
            } else {
                set(key, value);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 递增
     *
     * @param key   键
     * @param delta 要增加几（大于0）
     * @return
     */
    public long incr(String key, long delta) {
        if (delta < 0) {
            throw new RuntimeException("递增因子必须大于0");
        }
        return redisTemplate.opsForValue().increment(key, delta);
    }

    /**
     * 递减
     *
     * @param key   键
     * @param delta 要减少几(小于0)
     * @return
     */
    public long decr(String key, long delta) {
        if (delta < 0) {
            throw new RuntimeException("递减因子必须大于0");
        }
        return redisTemplate.opsForValue().increment(key, -delta);
    }

    // ================================Map=================================

    /**
     * HashGet
     *
     * @param key  键 不能为null
     * @param item 项 不能为null
     * @return 值
     */
    public Object hget(String key, String item) {
        if (StringUtils.isNotEmpty(key) && StringUtils.isNotEmpty(item)) {
            return redisTemplate.opsForHash().get(key, item);
        }
        return null;
    }

    /**
     * 获取hashKey对应的所有键值
     *
     * @param key 键
     * @return 对应的多个键值
     */
    public Map<Object, Object> hmget(String key) {
        if (StringUtils.isNotEmpty(key)) {
            return redisTemplate.opsForHash().entries(key);
        }
        return null;
    }

    /**
     * HashSet
     *
     * @param key 键
     * @param map 对应多个键值
     * @return true成功 false失败
     */
    public boolean hmset(String key, Map<String, Object> map) {
        try {
            redisTemplate.opsForHash().putAll(key, map);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * HashSet 并设置过期时间
     *
     * @param key  键
     * @param map  对应的多个键值
     * @param time 时间（秒）
     * @return true 成功 false失败
     */
    public boolean hmset(String key, Map<String, Object> map, long time) {
        try {
            redisTemplate.opsForHash().putAll(key, map);
            if (time > 0) {
                expire(key, time);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 向一张hash表中放入数据,如果不存在将创建
     *
     * @param key   键
     * @param item  项
     * @param value 值
     * @return true 成功 false失败
     */
    public boolean hset(String key, String item, Object value) {
        try {
            redisTemplate.opsForHash().put(key, item, value);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 向一张hash表中放入数据,如果不存在将创建
     *
     * @param key   键
     * @param item  项
     * @param value 值
     * @param time  时间(秒) 注意:如果已存在的hash表有时间,这里将会替换原有的时间
     * @return true 成功 false失败
     */
    public boolean hset(String key, String item, Object value, long time) {
        try {
            redisTemplate.opsForHash().put(key, item, value);
            if (time > 0) {
                expire(key, time);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 删除hash表中的值
     *
     * @param key  键 不能为null
     * @param item 项 可以使多个 不能为null
     */
    public void hdel(String key, Object... item) {
        redisTemplate.opsForHash().delete(key, item);
    }

    /**
     * 判断hash表中是否有该项的值
     *
     * @param key  键 不能为null
     * @param item 项 不能为null
     * @return true 存在 false不存在
     */
    public boolean hHasKey(String key, String item) {
        return redisTemplate.opsForHash().hasKey(key, item);
    }

    /**
     * hash递增 如果不存在,就会创建一个 并把新增后的值返回
     *
     * @param key  键
     * @param item 项
     * @param by   要增加几(大于0)
     * @return
     */
    public double hincr(String key, String item, double by) {
        return redisTemplate.opsForHash().increment(key, item, by);
    }

    /**
     * hash递减
     *
     * @param key  键
     * @param item 项
     * @param by   要减少记(小于0)
     * @return
     */
    public double hdecr(String key, String item, double by) {
        return redisTemplate.opsForHash().increment(key, item, -by);
    }

    // ============================set============================

    /**
     * 根据key获取Set中的所有值
     *
     * @param key 键
     * @return
     */
    public Set<Object> sGet(String key) {
        try {
            return redisTemplate.opsForSet().members(key);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 根据value从一个set中查询,是否存在
     *
     * @param key   键
     * @param value 值
     * @return true 存在 false不存在
     */
    public boolean sHasKey(String key, Object value) {
        try {
            return redisTemplate.opsForSet().isMember(key, value);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 将数据放入set缓存
     *
     * @param key    键
     * @param values 值 可以是多个
     * @return 成功个数
     */
    public long sSet(String key, Object... values) {
        try {
            return redisTemplate.opsForSet().add(key, values);
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * 将set数据放入缓存
     *
     * @param key    键
     * @param time   时间(秒)
     * @param values 值 可以是多个
     * @return 成功个数
     */
    public long sSetAndTime(String key, long time, Object... values) {
        try {
            Long count = redisTemplate.opsForSet().add(key, values);
            if (time > 0)
                expire(key, time);
            return count;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * 获取set缓存的长度
     *
     * @param key 键
     * @return
     */
    public long sGetSetSize(String key) {
        try {
            return redisTemplate.opsForSet().size(key);
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * 移除值为value的
     *
     * @param key    键
     * @param values 值 可以是多个
     * @return 移除的个数
     */
    public long setRemove(String key, Object... values) {
        try {
            Long count = redisTemplate.opsForSet().remove(key, values);
            return count;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    // ===============================list=================================

    /**
     * 获取list缓存的内容
     *
     * @param key   键
     * @param start 开始
     * @param end   结束 0 到 -1代表所有值
     * @return
     */
    public List<Object> lGet(String key, long start, long end) {
        try {
            return redisTemplate.opsForList().range(key, start, end);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 获取list缓存的长度
     *
     * @param key 键
     * @return
     */
    public long lGetListSize(String key) {
        try {
            return redisTemplate.opsForList().size(key);
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * 通过索引 获取list中的值
     *
     * @param key   键
     * @param index 索引 index>=0时， 0 表头，1 第二个元素，依次类推；index<0时，-1，表尾，-2倒数第二个元素，依次类推
     * @return
     */
    public Object lGetIndex(String key, long index) {
        try {
            return redisTemplate.opsForList().index(key, index);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * 将list放入缓存
     *
     * @param key   键
     * @param value 值
     * @return
     */
    public boolean lSet(String key, Object value) {
        try {
            redisTemplate.opsForList().rightPush(key, value);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 将list放入缓存
     *
     * @param key   键
     * @param value 值
     * @param time  时间(秒)
     * @return
     */
    public boolean lSet(String key, Object value, long time) {
        try {
            redisTemplate.opsForList().rightPush(key, value);
            if (time > 0)
                expire(key, time);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 将list放入缓存
     *
     * @param key   键
     * @param value 值
     * @return
     */
    public boolean lSet(String key, List<Object> value) {
        try {
            redisTemplate.opsForList().rightPushAll(key, value);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 将list放入缓存
     *
     * @param key   键
     * @param value 值
     * @param time  时间(秒)
     * @return
     */
    public boolean lSet(String key, List<Object> value, long time) {
        try {
            redisTemplate.opsForList().rightPushAll(key, value);
            if (time > 0)
                expire(key, time);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 根据索引修改list中的某条数据
     *
     * @param key   键
     * @param index 索引
     * @param value 值
     * @return
     */
    public boolean lUpdateIndex(String key, long index, Object value) {
        try {
            redisTemplate.opsForList().set(key, index, value);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 移除N个值为value
     *
     * @param key   键
     * @param count 移除多少个
     * @param value 值
     * @return 移除的个数
     */
    public long lRemove(String key, long count, Object value) {
        try {
            Long remove = redisTemplate.opsForList().remove(key, count, value);
            return remove;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * 移除左边的第一个元素
     *
     * @param key key
     * @return 移除的元素
     */
    public Object lpop(String key) {
        long size = redisTemplate.opsForList().size(key);
        if (size > 0) {
            // 移除左边的第一个元素
            return redisTemplate.opsForList().leftPop(key);
        }
        return null;
    }

    /**
     * 移除左边的第一个元素，如果没有元素则等待，超过指定时间则退出
     *
     * @param key  键
     * @param time 时间（秒）
     * @return 移除的元素
     */
    public Object lpop(String key, long time) {
        long size = redisTemplate.opsForList().size(key);
        if (size > 0) {
            return redisTemplate.opsForList().leftPop(key, time, TimeUnit.SECONDS);
        }
        return null;
    }

    /**
     * 移除右边的第一个元素
     *
     * @param key   键
     * @param clazz 类
     * @param <T>   泛型
     * @return
     */
    public <T> T rpop(String key, Class<T> clazz) {
        long size = redisTemplate.opsForList().size(key);
        if (size > 0) {
            // 移除右边的第一个元素
            Object pop = redisTemplate.opsForList().rightPop(key);
            return clazz.cast(pop);
        }
        return null;
    }

    /**
     * 移除右边的第一元素  如果没有元素则等待，超过指定时间则退出
     *
     * @param key   键
     * @param time  时间（秒）
     * @param clazz 类
     * @param <T>   返回的泛型
     * @return 移除的对象
     */
    public <T> T rpop(String key, long time, Class<T> clazz) {
        long size = redisTemplate.opsForList().size(key);
        if (size > 0) {
            // 移除右边的第一个元素
            Object pop = redisTemplate.opsForList().rightPop(key, time, TimeUnit.SECONDS);
            return clazz.cast(pop);
        }
        return null;
    }

    /**
     * 向集合最右边添加元素。
     *
     * @param key   键
     * @param value 值
     * @return 是否操作成功
     */
    public boolean rpush(String key, Object value) {
        try {
            if (StringUtils.isNotEmpty(key)) {
                return redisTemplate.opsForList().rightPush(key, value) > 0;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 向右边批量添加元素。
     * @param key 键
     * @param values 值集合
     * @return true操作成功! false操作失败
     */
    public boolean rpushlist(String key, List<Object> values) {
        try {
            if (StringUtils.isNotEmpty(key)) {
                return redisTemplate.opsForList().rightPushAll(key, values) > 0;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 向集合最左边添加元素。
     * @param key   键
     * @param value 值
     * @return 是否操作成功
     */
    public boolean lpush(String key, Object value) {
        try {
            if (StringUtils.isNotEmpty(key)) {
                return redisTemplate.opsForList().leftPush(key, value) > 0;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 向左边批量添加元素。
     * @param key 键
     * @param values 值集合
     * @return true操作成功! false操作失败
     */
    public boolean lpushlist(String key, List<Object> values) {
        try {
            if (StringUtils.isNotEmpty(key)) {
                return redisTemplate.opsForList().leftPushAll(key, values) > 0;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 获取集合的长度
     * @param key 键
     * @return 集合的长度
     */
    public Long size(String key) {
        if (StringUtils.isNotEmpty(key)) {
            return redisTemplate.opsForList().size(key);
        }
        return 0L;
    }

    /**
     * 从队列的右边获取数据
     * @param key 键
     * @param size 数量
     * @return
     */
    public List<Object> getRightList(String key, int size) {
        if (StringUtils.isNotEmpty(key) && size > 0) {
            long keySize = redisTemplate.opsForList().size(key);
            return redisTemplate.opsForList().range(key, keySize-size, keySize);
        }
        return null;
    }

    /**
     * 获取队列左边的数据集合
     * @param key 键
     * @param size 列表长度
     * @return 数据集合
     */
    public List<Object> getLeftList(String key, long size) {
        List<Object> list = redisTemplate.opsForList().range(key, 0, size-1);
        return list;
    }

    /**
     * 从左侧移除指定长度的数据
     * @param key 键
     * @param size 移除数据量
     * @return 是否操作成功 true成功  false失败
     */
    public boolean trimLeftList(String key, long size) {
        try {
            redisTemplate.opsForList().trim(key, size, -1);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
