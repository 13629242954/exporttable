package com.csg;

import com.csg.util.IdWorker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * <p>
 *
 * </p>
 *
 * @author GeorgeChan 2019/11/20 19:11
 * @version 1.0
 * @since jdk1.8
 */
@SpringBootApplication
@EnableTransactionManagement
public class MonitorSyncApplication {
    protected final static Logger LOGGER = LoggerFactory.getLogger(MonitorSyncApplication.class);

//    public MonitorSyncApplication(RedisTemplate redisTemplate) {
//        redisTemplate.opsForValue().set("spring-r-cluster-1", 123);
//        redisTemplate.opsForValue().set("spring-r-cluster-2", 456);
//        redisTemplate.opsForValue().set("spring-r-cluster-3", 789);
//
//        Object o = redisTemplate.opsForValue().get("spring-r-cluster-3");
//        String jsonString = JSON.toJSONString(o);
//        System.out.println("********** " + jsonString + "   *********");
//    }

    public static void main(String[] args) {
        SpringApplication.run(MonitorSyncApplication.class, args);
        LOGGER.info("springboot 启动成功......");
    }



    @Bean
    public IdWorker idWorkker(){
        return new IdWorker(1, 1);
    }
}
