package com.csg.controller;


import com.csg.service.IOilRecordService;
import com.csg.util.Result;
import com.csg.util.StatusCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author George Chan
 * @since 2019-11-24
 */
@RestController
@RequestMapping("/api/oilRecord")
public class OilRecordController {
    private static final Logger LOGGER = LoggerFactory.getLogger(OilRecordController.class);
    private final IOilRecordService oilRecordService;

    @Autowired
    public OilRecordController(IOilRecordService oilRecordService) {
        this.oilRecordService = oilRecordService;
    }

    /**
     * 数据同步
     * @return 返回结果
     */
    @GetMapping("/syncData")
    public Result syncOilRecord() {
        LOGGER.info("开始同步 rt_oil_record 数据");
        boolean res = oilRecordService.syncData();
        if (res) {
            return new Result(true, StatusCode.OK,"同步成功");
        }
        LOGGER.info("结束同步 rt_oil_record 数据");
        return new Result(false, StatusCode.ERROR, "同步失败");
    }
}
