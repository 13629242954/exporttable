package com.csg.controller;


import com.csg.common.Result;
import com.csg.service.IQuartzJobService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author George
 * @since 2019-11-15
 */
@Controller
@RequestMapping("/alarm/job")
public class QuartzJobController {
    private static final Logger LOGGER = LoggerFactory.getLogger(QuartzJobController.class);

    private final IQuartzJobService quartzJobService;

    @Autowired
    public QuartzJobController(IQuartzJobService quartzJobService) {
        this.quartzJobService = quartzJobService;
    }

    /**
     * 任务手动触发
     * @param jobName 任务名称
     * @param jobGroup 任务所属组
     */
    @PostMapping("/trigger")
    public Result trigger(@RequestParam String jobName, @RequestParam String jobGroup) {
        LOGGER.info("触发任务");
        Result result = quartzJobService.triggerJob(jobName, jobGroup);
        return result;
    }
}
