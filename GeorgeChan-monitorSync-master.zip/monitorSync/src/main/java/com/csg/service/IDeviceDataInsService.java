package com.csg.service;

import com.csg.entity.DeviceDataIns;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author George Chan
 * @since 2019-11-24
 */
public interface IDeviceDataInsService extends IService<DeviceDataIns> {

    /**
     * 数据同步
     * @return true 成功  false 失败
     */
    boolean syncData();
}
