package com.csg.service;

import com.csg.entity.Sms;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 短信发送记录 服务类
 * </p>
 *
 * @author George Chan
 * @since 2019-11-24
 */
public interface ISmsService extends IService<Sms> {
    /**
     * 数据同步
     * @return true 成功  false 失败
     */
    boolean syncData();
}
