package com.csg.service;

import com.csg.entity.Alarm;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 变电告警表 服务类
 * </p>
 *
 * @author George Chan
 * @since 2019-11-21
 */
public interface IAlarmService extends IService<Alarm> {

    /**
     * 同步告警数据
     * @return true 成功  false 失败
     */
    boolean syncData();
}
