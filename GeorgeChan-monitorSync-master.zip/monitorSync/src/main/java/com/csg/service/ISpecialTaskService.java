package com.csg.service;

import com.csg.entity.SpecialTask;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 特巡任务详细 服务类
 * </p>
 *
 * @author George Chan
 * @since 2019-11-24
 */
public interface ISpecialTaskService extends IService<SpecialTask> {
    /**
     * 数据同步
     * @return true 成功  false 失败
     */
    boolean syncData();
}
