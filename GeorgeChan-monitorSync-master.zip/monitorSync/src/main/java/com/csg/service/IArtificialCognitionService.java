package com.csg.service;

import com.csg.entity.ArtificialCognition;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author George Chan
 * @since 2019-11-25
 */
public interface IArtificialCognitionService extends IService<ArtificialCognition> {
    /**
     * 告警数据同步
     * @return 返回结果
     */
    boolean syncData();
}
