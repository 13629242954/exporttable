package com.csg.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.csg.common.Result;
import com.csg.entity.QuartzJob;
import com.github.pagehelper.PageInfo;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author George
 * @since 2019-11-15
 */
public interface IQuartzJobService extends IService<QuartzJob> {
    PageInfo listQuartzJob(String jobName, Integer pageNo, Integer pageSize);

    /**
     * 新增job
     * @param quartz
     * @return
     */
    Result saveJob(QuartzJob quartz);

    /**
     * 触发job
     * @param jobName
     * @param jobGroup
     * @return
     */
    Result triggerJob(String jobName, String jobGroup);

    /**
     * 暂停job
     * @param jobName
     * @param jobGroup
     * @return
     */
    Result pauseJob(String jobName, String jobGroup);

    /**
     * 恢复job
     * @param jobName
     * @param jobGroup
     * @return
     */
    Result resumeJob(String jobName, String jobGroup);

    /**
     * 移除job
     * @param jobName
     * @param jobGroup
     * @return
     */
    Result removeJob(String jobName, String jobGroup);

    QuartzJob getJob(String jobName, String jobGroup);

    Result updateJob(QuartzJob quartz);

    void schedulerJob(QuartzJob job) throws Exception;
}
