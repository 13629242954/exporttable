package com.scg.generator;

import com.baomidou.mybatisplus.annotation.DbType;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.core.exceptions.MybatisPlusException;
import com.baomidou.mybatisplus.core.toolkit.StringPool;
import com.baomidou.mybatisplus.generator.AutoGenerator;
import com.baomidou.mybatisplus.generator.InjectionConfig;
import com.baomidou.mybatisplus.generator.config.*;
import com.baomidou.mybatisplus.generator.config.po.TableInfo;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import com.baomidou.mybatisplus.generator.engine.FreemarkerTemplateEngine;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * <p>
 *
 * </p>
 *
 * @author GeorgeChan 2019/11/14 17:04
 * @version 1.0
 * @since jdk1.8
 */
public class DmGenerator {
    public static String scanner(String tip) {
        Scanner scanner = new Scanner(System.in);
        StringBuilder help = new StringBuilder();
        help.append("请输入" + tip + "：");
        System.out.println(help.toString());
        if (scanner.hasNext()) {
            String ipt = scanner.next();
            if (StringUtils.isNotEmpty(ipt)) {
                return ipt;
            }
        }
        throw new MybatisPlusException("请输入正确的" + tip + "！");
    }

    public static void main(String[] args) {
        // 代码生成器
        AutoGenerator mpg = new AutoGenerator();
        // 全局配置
        GlobalConfig gc = new GlobalConfig();
        String projectPath = System.getProperty("user.dir");
        gc.setOutputDir(projectPath + "/src/main/java");
        gc.setAuthor("George Chan");
        gc.setOpen(false);
        gc.setSwagger2(false);
        gc.setIdType(IdType.ID_WORKER);
        gc.setBaseResultMap(true);
        gc.setFileOverride(false);
        mpg.setGlobalConfig(gc);

        //达梦数据库的配置
        DataSourceConfig dsc = new DataSourceConfig();
        dsc.setDbType(DbType.DM);
        dsc.setUrl("jdbc:dm://192.168.6.32:5236");
        dsc.setDriverName("dm.jdbc.driver.DmDriver");
        dsc.setUsername("SYSDBA");
        dsc.setPassword("SYSDBA");
        dsc.setSchemaName("MONITOR_VISUAL");
//        dsc.setDbType(DbType.MYSQL);
//        dsc.setUrl("jdbc:mysql://106.14.137.255:3306/etro_rt?useUnicode=true&characterEncoding=utf-8&useSSL=true&serverTimezone=UTC");
//        dsc.setDriverName("com.mysql.cj.jdbc.Driver");
//        dsc.setUsername("root");
//        dsc.setPassword("123456");
        mpg.setDataSource(dsc);

        // 包配置
        PackageConfig pc = new PackageConfig();
//        pc.setModuleName();
        pc.setParent("com.csg");
        mpg.setPackageInfo(pc);

        // 自定义配置
        InjectionConfig cfg = new InjectionConfig() {
            @Override
            public void initMap() {
                // to do nothing
            }
        };
        List<FileOutConfig> focList = new ArrayList<>();
        focList.add(new FileOutConfig("/templates/mapper.xml.ftl") {
            @Override
            public String outputFile(TableInfo tableInfo) {
                // 自定义输入文件名称
//                return projectPath + "/src/main/resources/mapper/" + pc.getModuleName()
//                        + "/" + tableInfo.getEntityName() + "Mapper" + StringPool.DOT_XML;

                return projectPath + "/src/main/resources/mapper/" + StringPool.EMPTY
                        + "/" + tableInfo.getEntityName() + "Mapper" + StringPool.DOT_XML;
            }
        });
        cfg.setFileOutConfigList(focList);
        mpg.setCfg(cfg);
        mpg.setTemplate(new TemplateConfig().setXml(null));

        // 策略配置
        StrategyConfig strategy = new StrategyConfig();
        strategy.setNaming(NamingStrategy.underline_to_camel);
        strategy.setColumnNaming(NamingStrategy.underline_to_camel);
        strategy.setEntityLombokModel(true);
        strategy.setTablePrefix(new String[]{"RT_"});// 此处可以修改为您的表前缀
//        strategy.setInclude(new String[] {"rt_audit"}); // 需要生成的表
        strategy.setInclude(new String[] {
                "RT_ALARM","RT_DEVICE_DATA_INF","RT_DEVICE_DATA_INS","RT_ENERGY_LOG",
                "RT_OIL_RECORD","RT_WEATHER_RECORD","RT_DATA_DETAIL","RT_TASK_DATA",
                "RT_THERMAL_DEFECT","RT_TRIPHASE_TEM","RT_TASK_PLANE","RT_TASK_PAUSE",
                "RT_TASK_DETAIL","RT_SPECIAL_TASK","RT_SMS","RT_OIL_LIMIT","RT_MEDIA_MANAGE",
                "RT_DEVICE_ALARM","RT_ARTIFICIAL_COGNITION","RT_ENVIRONMENT_INFO" }); // 需要生成的表
        strategy.setSuperEntityColumns(null);
        strategy.setControllerMappingHyphenStyle(true);
        strategy.setEntityLombokModel(true);
        strategy.setEntityTableFieldAnnotationEnable(true);
        strategy.setEntitySerialVersionUID(true);
        strategy.setCapitalMode(true);
        mpg.setStrategy(strategy);
        // 选择 freemarker 引擎需要指定如下加，注意 pom 依赖必须有！
        mpg.setTemplateEngine(new FreemarkerTemplateEngine());
        mpg.execute();
    }
}
