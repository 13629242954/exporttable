##### springboot + mybatis 整合国产达梦数据库实现简单CRUD
##### 数据表根据实体类建立即可

###### 数据库安装参考：https://blog.csdn.net/fengxiaozhenjay/article/details/100668217

