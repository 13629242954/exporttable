package com.dc.utill;

import com.dc.entity.TestUser;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * @Author: wzj
 * @Date: 2020/5/19 15:29
 */
public class PoiInputUser {
    public static List<TestUser> inputExcel(String path) {
        ArrayList<TestUser> list = new ArrayList<>();
        try {
            //1、获取文件输入流
            InputStream inputStream = new FileInputStream(path);
            //获取文件格式
            String str1 = path.substring(0, path.indexOf("."));
            String str2 = path.substring(str1.length() + 1, path.length());
            Workbook workbook =null;
            Sheet sheetAt =null;
            if (str2.equals("xls")) {
                //2、获取Excel工作簿对象
                workbook = new HSSFWorkbook(inputStream);
                //3、得到Excel工作表对象
                sheetAt = workbook.getSheetAt(0);
                //4、循环读取表格数据
            } else {
                workbook = new XSSFWorkbook(inputStream);
                sheetAt = workbook.getSheetAt(0);
                //4、循环读取表格数据
                for (Row row : sheetAt) {
                    //首行（即表头）不读取
                    if (row.getRowNum() == 0) {
                        continue;
                    }
                    //读取当前行中单元格数据，索引从0开始
                    Integer uid = (int)row.getCell(0).getNumericCellValue();
                    String uname = row.getCell(1).getStringCellValue();
                    TestUser user = new TestUser(uid,uname);
                    list.add(user);
                }
                //5、关闭流
                workbook.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }
}
