package com.dc.utill;

import com.dc.entity.TestUser;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
/**
 * @Author: wzj
 * @Date: 2020/5/19 14:58
 */
public class PoiOutUser {
    public static void outExcel(List<TestUser> list,String path) {
        //创建工作簿 类似于创建Excel文件
        XSSFWorkbook workbook=new XSSFWorkbook();
        //创建 sheetname页名
        XSSFSheet sheet = workbook.createSheet("表1");
        sheet.setColumnWidth(3,20*256);//给第3列设置为20个字的宽度
        sheet.setColumnWidth(4,20*256);//给第4列设置为20个字的宽度
        //创建一行,下标从0开始
        XSSFRow row = sheet.createRow(0);
        //创建这行中的列,下标从0开始 （表头）
        XSSFCell cell = row.createCell(0);
        // 给cell 0下表赋值
        cell.setCellValue("编号");
        //创建这行中的列,并给该列直接赋值
        row.createCell(1).setCellValue("名字");
        // 设置表里内容
        for (int i = 0 ; i<list.size();i++){
            row = sheet.createRow(i+1);
            row.createCell(0).setCellValue(list.get(i).getUid());
            row.createCell(1).setCellValue(list.get(i).getUname());
        }
        //设定 路径必须存在  "D:\\打印测试\\用户信息.xlsx"
        File file = new File(path);
        FileOutputStream stream = null;
        try {
            stream = new FileOutputStream(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        // 需要抛异常
        try {
            workbook.write(stream);
            //关闭流
            stream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }

    }
}
